const { SSMClient, GetParametersCommand } = require("@aws-sdk/client-ssm");

async function loadParameters() {
  // Load .env first to check LOCAL_DEV flag
  require("dotenv").config();

  // ============================================
  // PRIORITY 1: Local Development
  // Set LOCAL_DEV=true to use .env file
  // ============================================
  if (process.env.LOCAL_DEV === "true") {
    console.log("✓ Loading from .env (LOCAL DEVELOPMENT)");
    return;
  }

  const client = new SSMClient({ region: process.env.AWS_REGION || "ap-south-1" });

  // ============================================
  // PRIORITY 2 & 3: AWS EB (Parameter Store)
  // NODE_ENV=development → /odts/dev/*
  // NODE_ENV=production  → /odts/prod/*
  // ============================================
  try {
    const paramEnv = process.env.PARAM_ENV || "dev";
    const nodeEnv = process.env.NODE_ENV || "development";

    console.log(`✓ Loading parameters from AWS Parameter Store (/odts/${paramEnv}/)`);

    const params = [
      `/odts/${paramEnv}/DB_HOST`,
      `/odts/${paramEnv}/DB_PORT`,
      `/odts/${paramEnv}/DB_USER`,
      `/odts/${paramEnv}/DB_PASSWORD`,
      `/odts/${paramEnv}/DB_NAME`,
      `/odts/${paramEnv}/SESSION_SECRET`,
      `/odts/${paramEnv}/FIREBASE_API_KEY`,
      `/odts/${paramEnv}/FIREBASE_AUTH_DOMAIN`,
      `/odts/${paramEnv}/FIREBASE_DATABASE_URL`,
      `/odts/${paramEnv}/FIREBASE_PROJECT_ID`,
      `/odts/${paramEnv}/PORT`,
    ];

    const command = new GetParametersCommand({
      Names: params,
      WithDecryption: true,
    });

    const response = await client.send(command);

    if (response.InvalidParameters?.length > 0) {
      console.error("❌ Missing parameters:", response.InvalidParameters);
      throw new Error(`Missing parameters: ${response.InvalidParameters.join(", ")}`);
    }

    response.Parameters.forEach(param => {
      const key = param.Name.split("/").pop();
      process.env[key] = param.Value;
    });

    console.log(`✓ Loaded ${response.Parameters.length} parameters (NODE_ENV=${nodeEnv})`);
  } catch (error) {
    console.error("❌ Failed to load parameters:", error.message);
    process.exit(1);
  }
}

module.exports = { loadParameters };
